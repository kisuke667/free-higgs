# FREE HIGGS — pipeline vidéo multi-fournisseurs

Interface web autonome en français, adaptée au mobile. Cette version ajoute des adaptateurs vidéo à la configuration multi-clés.

## Adaptateurs vidéo intégrés

- **Agnès AI** : pipeline d’origine conservé.
- **Pollinations AI** : génération vidéo synchrone via `GET /video/{prompt}`. Le MP4 est conservé comme URL temporaire dans la session navigateur; il faut l’exporter avant de fermer la page.
- **Runware** : `videoInference` asynchrone puis `getResponse` par `taskUUID`.
- **KIE AI** : `POST /api/v1/jobs/createTask`, suivi par `GET /api/v1/jobs/recordInfo?taskId=...`. Le modèle se règle dans le champ Modèle vidéo.
- **WaveSpeed AI** : requête au endpoint du modèle saisi, puis suivi de la prédiction. Vérifiez le nom exact du modèle et la route selon la documentation du compte.

- **Magic Hour** : `POST /v1/text-to-video` puis suivi par `GET /v1/video-projects/{id}` jusqu'à `complete`. Champ Modèle vidéo : `default`, `kling-3.0`, `seedance-2.0`, `veo3.1`, etc. (clé : `Bearer`).
- **Higgsfield** : `POST https://api.higgsfield.ai/{chemin-du-modèle}` puis suivi via `status_url`. Le champ Modèle vidéo contient le chemin (ex. `kling-video/v2.6/pro/text-to-video`). La clé se saisit sous la forme `ID:SECRET` (en-tête `Key ID:SECRET`). Seuls `prompt` et `aspect_ratio` sont envoyés (certains modèles refusent les champs inconnus).
- **GLIF** : API simple `POST https://simple-api.glif.app` avec `{id, inputs:[prompt]}`. Le champ Modèle vidéo contient l'**ID de votre workflow**, qui doit renvoyer une URL vidéo.

## Fournisseurs sans adaptateur vidéo

**Hugging Face**, **APIPass** et **Kaggle** restent visibles dans le sélecteur mais ne sont pas exploitables pour la vidéo :
- Hugging Face : la route vidéo dépend du fournisseur d'inférence choisi (fal-ai, WaveSpeed, Novita…), sans protocole HTTP unique vérifié pour le navigateur.
- APIPass : endpoint exact non vérifié dans la documentation consultée.
- Kaggle : plateforme de notebooks, pas d'API vidéo publique uniforme.

Le pipeline affiche un message explicite pour ces fournisseurs. « HUGINFACE » a été interprété comme Hugging Face et « POLINATION » comme Pollinations AI.

## Configuration

1. Ouvrir **Clés API**.
2. Sélectionner le fournisseur, saisir la clé et le modèle exact.
3. Pour WaveSpeed, le champ modèle doit correspondre à la route modèle indiquée par WaveSpeed.
4. Les fournisseurs peuvent bloquer les appels directs depuis le navigateur (CORS). Si c’est le cas, il faut un backend/proxy sécurisé.

## Sécurité et limites

- Les clés API sont conservées localement dans le navigateur et ne sont pas chiffrées. Ne déployez pas l’application publiquement en y mettant vos clés.
- Les API directes depuis le navigateur exposent la clé au client et peuvent être bloquées par CORS. Pour un usage public, utilisez un backend sécurisé avec secrets côté serveur.
- Les modèles et formats d’entrée diffèrent. Les adaptateurs ont été testés avec des réponses simulées, pas avec des clés valides; testez un modèle et un compte avant une production complète.
- Les URLs générées par les fournisseurs peuvent expirer.

## Documentation consultée

- Pollinations : https://gen.pollinations.ai/
- Runware : https://runware.ai/video-generation-api
- KIE AI : https://docs.kie.ai/
- WaveSpeed : https://wavespeed.ai/
- Hugging Face : https://huggingface.co/docs/inference-providers/en/index
- Magic Hour : https://docs.magichour.ai/api-reference/video-projects/text-to-video
- Higgsfield : https://docs.higgsfield.ai/
- GLIF : https://docs.glif.app/hack-the-planet/api-for-developers
